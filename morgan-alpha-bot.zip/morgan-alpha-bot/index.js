require('dotenv').config();

const express = require('express');
const qrcode = require('qrcode-terminal');
const { Client, LocalAuth } = require('whatsapp-web.js');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const BOT_NAME = process.env.BOT_NAME || 'Morgan-Alpha Bot';
const PREFIX = process.env.COMMAND_PREFIX || '..';
const OWNER_NUMBER = (process.env.OWNER_NUMBER || '').replace(/\D/g, '');
const AUTO_REPLY = String(process.env.AUTO_REPLY || 'true').toLowerCase() === 'true';

let status = 'starting';
let lastQrAt = null;

app.get('/', (_req, res) => {
  res.type('html').send(`<!doctype html><html><head><meta name="viewport" content="width=device-width, initial-scale=1"><title>${escapeHtml(BOT_NAME)}</title></head>
  <body style="font-family:system-ui;max-width:680px;margin:40px auto;padding:0 18px;background:#101714;color:#eef8f1">
  <h1>🤖 ${escapeHtml(BOT_NAME)}</h1><p>WhatsApp bot service is running.</p>
  <p>Status: <strong>${escapeHtml(status)}</strong></p>
  <p>Commands use the <code>${escapeHtml(PREFIX)}</code> prefix. QR login is shown in the private server logs, not on this public page.</p>
  <p><a style="color:#7ee2a8" href="/health">Health status</a></p></body></html>`);
});
app.get('/health', (_req, res) => res.json({ ok: true, bot: BOT_NAME, whatsapp: status, uptimeSeconds: Math.floor(process.uptime()) }));
app.listen(PORT, () => console.log(`Web service listening on ${PORT}`));

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}

const client = new Client({
  authStrategy: new LocalAuth({ clientId: 'morgan-alpha' }),
  puppeteer: {
    headless: true,
    args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage']
  }
});

client.on('qr', qr => {
  status = 'waiting_for_qr_scan';
  lastQrAt = new Date().toISOString();
  console.log('\\nScan this QR code using WhatsApp > Linked devices > Link a device.');
  console.log('Only scan it on your own server and never share a screenshot of it.\\n');
  qrcode.generate(qr, { small: true });
});
client.on('authenticated', () => {
  status = 'authenticated';
  console.log('WhatsApp authentication received.');
});
client.on('ready', () => {
  status = 'connected';
  console.log(`${BOT_NAME} is connected and ready.`);
});
client.on('auth_failure', msg => {
  status = 'auth_failure';
  console.error('WhatsApp authentication failed:', msg);
});
client.on('disconnected', reason => {
  status = 'disconnected';
  console.warn('WhatsApp disconnected:', reason);
});

client.on('message', async msg => {
  try {
    if (msg.fromMe || msg.from.endsWith('@g.us') || msg.from === 'status@broadcast') return;
    const body = (msg.body || '').trim();
    if (!body) return;

    const command = body.toLowerCase();
    if (command === `${PREFIX}menu`) {
      await msg.reply(
        `🤖 *${BOT_NAME}*\\n\\n` +
        `${PREFIX}menu - Show commands\\n` +
        `${PREFIX}ping - Check bot status\\n` +
        `${PREFIX}owner - Owner contact\\n\\n` +
        `Auto-replies: ${AUTO_REPLY ? 'ON' : 'OFF'}`
      );
      return;
    }
    if (command === `${PREFIX}ping`) {
      await msg.reply(`🏓 Pong! ${BOT_NAME} is online.`);
      return;
    }
    if (command === `${PREFIX}owner`) {
      await msg.reply(OWNER_NUMBER
        ? `👑 Bot owner: wa.me/${OWNER_NUMBER}`
        : 'Owner number has not been configured yet.');
      return;
    }

    if (body.startsWith(PREFIX)) return; // Unknown commands do not trigger auto-replies.
    if (!AUTO_REPLY) return;

    // Simple default auto-reply. Customize this text for your needs.
    await msg.reply(
      `👋 Hi! Thanks for messaging. I'm using *${BOT_NAME}* 🤖\\n` +
      `I've received your message and will reply when I'm available.\\n\\n` +
      `Type *${PREFIX}menu* to see bot commands.`
    );
  } catch (err) {
    console.error('Failed to process message:', err.message);
  }
});

process.on('unhandledRejection', err => console.error('Unhandled rejection:', err));
client.initialize();
